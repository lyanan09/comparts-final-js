# README

MA Computational Arts final project

A space trying to disrupt traditional ways of reading and challenge audience expectations, exploring how people's communication of information is affected through visual dislocation, choice of text and social interaction.

## Words

> Please stand in front of the white line
> 
> Have a look around
> 
> Hunted by pineapples
> 
> Greasy as a waxed mannequin
> 
> Try not to spit out the breakfast you never had
> 
> Don't you think desserts are too sweet
> 
> Put that into the missing dishwasher
> 
> Really have nothing to say
> 
> When can these nonsense be done
> 
> Please stay a bit longer
> 
> Make eye contact with random strangers
> 
> Everything ends


## Run this

npm install

npm start
